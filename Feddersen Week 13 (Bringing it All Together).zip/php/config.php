<?php

$hn = "localhost";
$un = "root";
$pw = "mysql";
$db = "final project";

?>